import java.util.ArrayList;

public class test {
    public static void main(String[] args) {

        //ListEtudiant listEtudiant = new ListEtudiant("L2","CPI2");

        /*CreerEtudiant formulaireEtudiant = new CreerEtudiant();
        formulaireEtudiant.setVisible(true);*/
        new Accueil();

    }
}
