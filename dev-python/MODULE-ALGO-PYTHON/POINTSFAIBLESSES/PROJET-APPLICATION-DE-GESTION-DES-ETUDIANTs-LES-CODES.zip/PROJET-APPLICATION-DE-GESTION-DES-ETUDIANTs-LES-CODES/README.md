# PROJET-APPLICATION-DE-GESTION-DES-ETUDIANTs
          
         ####### INTELLIJ IDEA + XAMPP ########
         
         
L’objectif du projet est de créer une application permettant de gérer les étudiants d’une école de formation.
L’école de formation a des filières, et chaque filière a des niveaux allant de Licence 1 a Master 2.
L’application doit utiliser une base de donner open source et permettra
• D’ajouter de modifier et de supprimer des filières. Lorsqu’on créer une filière, les niveaux L1 a M2 sont créés en même temps.
• D’ajouter un étudiant a une filière en spécifiant le niveau
• Lister les étudiants d’une filière
• Lister les étudiant d’une classe (niveau d’une filière)

